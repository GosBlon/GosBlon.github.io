const casio = document.querySelector('.casio');
const menu = document.querySelector('.menu-navegacion');



casio.addEventListener('click' , ()=>{
    menu.classList.toggle("spread")
})

window.addEventListener('click' , e=>{
      if(menu.classList.contains('spread')
      	
    && e.target != menu && e.target != casio  ){
    console.log('cerrar')
        menu.classList.toggle("spread")
    }
})
      