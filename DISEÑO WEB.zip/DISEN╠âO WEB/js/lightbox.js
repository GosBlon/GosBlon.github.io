const imagenes = document.querySelectorAll('.img-galeria')
const imagenesLight =document.querySelector('.agregar-imagen');
const imagenesLight =document.querySelector('.imagen-light')
const closeLight = document.querySelector('.close')

imagenes.forEach (imagen =>{
	imagen.addEventListener('click' , ()=>{
	 aparecerImagen(imagen.getAttribute('src'));
	
	})

})



contenedorLigth.addEventListener('click' , (e)=>{
	 if (e.target !==imagenesLight) {
        contenedorLigth.classList.toggle('show')
        imagenesLight.classList.toggle('showImage')
        casio1.style.opacity = '1'; 
	 }
})

const aparecerImagen = (imagen)=>{
	imagenesLight.src = imagen
	contenedorLigth.classList.toggle('show')
	imagenesLight.classList.toggle('showImage')
	casio1.style.opacity = '0'; 

}
